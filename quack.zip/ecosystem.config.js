module.exports = {
  apps: [
    {
      name: "quack",
      script: "./quack.js",
    },
  ],
};
